import React from 'react'
import Top from './Comp/Top'
import Header from './Comp/Header'
import Footer from './Comp/Footer'

function App() {
  return (
    < >
      <Top/>
      <Header/>
      <Footer/>
    </ >
  )
}

export default App
